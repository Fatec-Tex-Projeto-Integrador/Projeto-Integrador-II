<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
  <title>Gráfico de Pneus</title>
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body {
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      background: linear-gradient(135deg, #0f2027, #203a43, #2c5364);
      min-height: 100vh;
      color: white;
      padding: 20px;
    }

    .phone {
      width: 380px;
      height: 780px;
      background: #000;
      border-radius: 40px;
      padding: 10px;
      box-shadow: 0 20px 60px rgba(0,0,0,0.5);
      margin: 0 auto;
      position: relative;
      overflow: hidden;
    }

    .screen {
      width: 100%;
      height: 100%;
      background: #1a1a2e;
      border-radius: 30px;
      overflow: hidden;
      display: flex;
      flex-direction: column;
    }

    .status-bar { height: 44px; background: rgba(255,255,255,0.1); backdrop-filter: blur(10px); display: flex; align-items: center; justify-content: space-between; padding: 0 22px; font-size: 15px; color: white; }
    .notch { position: absolute; top: 0; left: 50%; transform: translateX(-50%); width: 180px; height: 30px; background: #000; border-bottom-left-radius: 20px; border-bottom-right-radius: 20px; }

    .header {
      padding: 20px;
      text-align: center;
      background: rgba(0,0,0,0.2);
    }

    .header h1 {
      font-size: 20px;
      font-weight: 600;
    }

    .chart-container {
      flex: 1;
      padding: 20px;
      position: relative;
    }

    canvas {
      max-height: 100%;
    }

    .legend {
      display: flex;
      justify-content: center;
      gap: 20px;
      margin-top: 10px;
      font-size: 14px;
    }

    .legend-item {
      display: flex;
      align-items: center;
      gap: 6px;
    }

    .legend-color {
      width: 12px;
      height: 12px;
      border-radius: 50%;
    }

    .back-btn {
      position: absolute;
      top: 60px;
      left: 20px;
      color: white;
      font-size: 20px;
      z-index: 10;
      text-decoration: none;
    }
  </style>
</head>
<body>

<div class="phone">
  <div class="screen">
    <div class="status-bar">
      <div>09:41</div>
      <div><i class="fas fa-signal"></i> <i class="fas fa-wifi"></i> <i class="fas fa-battery-full"></i></div>
    </div>
    <div class="notch"></div>

    <a href="index.php" class="back-btn"><i class="fas fa-arrow-left"></i></a>

    <div class="header">
      <h1>Gráfico em Tempo Real</h1>
      <p>Pressão e Temperatura</p>
    </div>

    <div class="chart-container">
      <canvas id="myChart"></canvas>
    </div>

    <div class="legend">
      <div class="legend-item">
        <div class="legend-color" style="background: #4bc0c0;"></div>
        <span>Pressão (psi)</span>
      </div>
      <div class="legend-item">
        <div class="legend-color" style="background: #ff9f40;"></div>
        <span>Temperatura (°C)</span>
      </div>
    </div>
  </div>
</div>

<script>
const ctx = document.getElementById('myChart').getContext('2d');
let chart;

function loadData() {
  fetch('get_data.php')
    .then(response => response.json())
    .then(data => {
      console.log('Dados recebidos:', data); // DEBUG

      if (!data || data.length === 0) {
        document.querySelector('.chart-container').innerHTML = 
          '<div style="text-align:center; padding:60px; color:#aaa;"><i class="fas fa-chart-line" style="font-size:48px; display:block; margin-bottom:16px;"></i>Aguardando dados...</div>';
        return;
      }

      const labels = data.map(d => d.hora);
      const pressao = data.map(d => d.pressao);
      const temp = data.map(d => d.temperatura);

      if (chart) {
        chart.data.labels = labels;
        chart.data.datasets[0].data = pressao;
        chart.data.datasets[1].data = temp;
        chart.update();
      } else {
        chart = new Chart(ctx, {
          type: 'line',
          data: {
            labels: labels,
            datasets: [
              {
                label: 'Pressão (psi)',
                data: pressao,
                borderColor: '#4bc0c0',
                backgroundColor: 'rgba(75, 192, 192, 0.1)',
                tension: 0.3,
                fill: true,
                pointRadius: 5
              },
              {
                label: 'Temperatura (°C)',
                data: temp,
                borderColor: '#ff9 Chip40',
                backgroundColor: 'rgba(255, 159, 64, 0.1)',
                tension: 0.3,
                fill: true,
                pointRadius: 5
              }
            ]
          },
          options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
              legend: { display: false },
              tooltip: { mode: 'index', intersect: false }
            },
            scales: {
              y: {
                beginAtZero: false,
                grid: { color: 'rgba(255,255,255,0.1)' },
                ticks: { color: '#ccc' }
              },
              x: {
                grid: { display: false },
                ticks: { color: '#ccc', maxTicksLimit: 6 }
              }
            }
          }
        });
      }
    })
    .catch(err => {
      console.error('Erro ao carregar dados:', err);
    });
}

// Atualiza a cada 3 segundos
setInterval(loadData, 3000);
loadData();
</script>

</body>
</html>