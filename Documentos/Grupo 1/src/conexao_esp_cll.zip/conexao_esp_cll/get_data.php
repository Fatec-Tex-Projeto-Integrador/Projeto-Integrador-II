<?php
header('Content-Type: application/json');
include 'conexao.php';

// Verifica conexão
if ($conn->connect_error) {
    echo json_encode([]);
    exit;
}

$sql = "SELECT pressao, temperatura, data_hora FROM sensores ORDER BY id DESC LIMIT 20";
$resultado = $conn->query($sql);

$dados = [];
while ($linha = $resultado->fetch_assoc()) {
    // Converte hPa para psi (1 hPa ≈ 0.0145 psi)
    $pressao_psi = round($linha['pressao'] * 0.0145, 2);
    
    $dados[] = [
        'pressao' => $pressao_psi,
        'temperatura' => $linha['temperatura'],
        'hora' => date('H:i', strtotime($linha['data_hora']))
    ];
}

echo json_encode(array_reverse($dados)); // Ordem cronológica
$conn->close();
?>