<?php
include 'conexao.php';

if (isset($_GET['temperatura']) && isset($_GET['pressao'])) {
  $temperatura = $_GET['temperatura'];
  $pressao = $_GET['pressao'];

  $sql = "INSERT INTO sensores (temperatura, pressao) VALUES ('$temperatura', '$pressao')";

  if ($conn->query($sql) === TRUE) {
    echo "Dados inseridos com sucesso!";
  } else {
    echo "Erro: " . $conn->error;
  }
} else {
  echo "Parâmetros ausentes!";
}

$conn->close();
?>
