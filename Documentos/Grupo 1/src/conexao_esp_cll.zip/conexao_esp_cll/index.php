<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
  <title>Teste de Pneus</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body {
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
      min-height: 100vh;
      display: flex;
      justify-content: center;
      padding: 20px;
    }

    .phone {
      width: 380px;
      height: 780px;
      background: #000;
      border-radius: 40px;
      padding: 10px;
      box-shadow: 0 20px 60px rgba(0,0,0,0.4);
      position: relative;
      overflow: hidden;
      margin: 0 auto;
    }

    .screen {
      width: 100%;
      height: 100%;
      background: #f4f6f9;
      border-radius: 30px;
      overflow: hidden;
      display: flex;
      flex-direction: column;
    }

    .status-bar {
      height: 44px;
      background: rgba(255,255,255,0.95);
      backdrop-filter: blur(10px);
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 0 22px;
      font-size: 15px;
      font-weight: 600;
      color: #000;
      z-index: 10;
    }

    .status-bar .time { font-weight: 600; }
    .status-bar .icons i { font-size: 17px; margin-left: 5px; }

    .notch {
      position: absolute;
      top: 0;
      left: 50%;
      transform: translateX(-50%);
      width: 180px;
      height: 30px;
      background: #000;
      border-bottom-left-radius: 20px;
      border-bottom-right-radius: 20px;
      z-index: 11;
    }

    .header {
      background: linear-gradient(135deg, #1e3c72, #2a5298);
      color: white;
      padding: 20px 20px 25px;
      text-align: center;
    }

    .header i {
      font-size: 38px;
      margin-bottom: 8px;
    }

    .header h1 {
      font-size: 22px;
      font-weight: 600;
    }

    .header p {
      font-size: 14px;
      opacity: 0.9;
      margin-top: 4px;
    }

    .content {
      flex: 1;
      overflow-y: auto;
      padding: 15px;
    }

    .table-container {
      background: white;
      border-radius: 16px;
      overflow: hidden;
      box-shadow: 0 4px 12px rgba(0,0,0,0.1);
      margin-bottom: 15px;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      font-size: 14px;
    }

    th {
      background: #1e3c72;
      color: white;
      padding: 12px 8px;
      font-weight: 600;
      font-size: 13px;
      text-align: center;
    }

    td {
      padding: 12px 8px;
      text-align: center;
      border-bottom: 1px solid #eee;
      font-size: 14px;
    }

    tr:last-child td { border-bottom: none; }

    .status {
      padding: 4px 10px;
      border-radius: 12px;
      font-size: 12px;
      font-weight: 700;
      text-transform: uppercase;
    }

    .ok { background: #e8f5e8; color: #2e7d32; }
    .atencao { background: #fff8e1; color: #f9a825; }
    .critico { background: #ffebee; color: #c62828; }

    .btn-grafico {
      display: block;
      width: 90%;
      margin: 20px auto;
      padding: 14px;
      background: #2a5298;
      color: white;
      text-align: center;
      border-radius: 12px;
      font-weight: 600;
      text-decoration: none;
      box-shadow: 0 4px 10px rgba(42, 82, 152, 0.3);
      transition: 0.2s;
    }

    .btn-grafico:hover {
      background: #1e3c72;
      transform: translateY(-1px);
    }

    .empty {
      text-align: center;
      padding: 50px 20px;
      color: #777;
      font-size: 15px;
    }

    .empty i {
      font-size: 50px;
      color: #ddd;
      margin-bottom: 15px;
    }

    .content::-webkit-scrollbar { width: 4px; }
    .content::-webkit-scrollbar-thumb { background: rgba(0,0,0,0.2); border-radius: 2px; }
  </style>
</head>
<body>

<div class="phone">
  <div class="screen">
    <div class="status-bar">
      <div class="time" id="time">09:41</div>
      <div class="icons">
        <i class="fas fa-signal"></i>
        <i class="fas fa-wifi"></i>
        <i class="fas fa-battery-full"></i>
      </div>
    </div>
    <div class="notch"></div>

    <div class="header">
      <i class="fas fa-car-side"></i>
      <h1>Teste de Pneus</h1>
      <p>Monitoramento em tempo real</p>
    </div>

    <div class="content">
      <div class="table-container">
        <table>
          <tr>
            <th>ID</th>
            <th>Pressão</th>
            <th>Temp.</th>
            <th>Status</th>
            <th>Hora</th>
          </tr>
          <?php
          include 'conexao.php';

          if ($conn->connect_error) {
              echo '<tr><td colspan="5" class="empty">Erro de conexão</td></tr>';
          } else {
              $sql = "SELECT * FROM sensores ORDER BY id DESC LIMIT 15";
              $resultado = $conn->query($sql);

              if ($resultado && $resultado->num_rows > 0) {
                  while ($linha = $resultado->fetch_assoc()) {
                      // Converte hPa → psi (para BMP280)
                      $pressao_psi = round($linha['pressao'] * 0.0145, 2);
                      $temp = floatval($linha['temperatura']);
                      $hora = date('H:i', strtotime($linha['data_hora']));

                      // Status baseado em pressão atmosférica (BMP280)
                      if ($pressao_psi < 13.5 || $pressao_psi > 15.0 || $temp >= 70) {
                          $status = 'critico';
                          $texto = 'CRÍTICO';
                      } elseif ($pressao_psi < 14.0 || $pressao_psi > 14.8 || $temp >= 60) {
                          $status = 'atencao';
                          $texto = 'ATENÇÃO';
                      } else {
                          $status = 'ok';
                          $texto = 'OK';
                      }

                      echo "<tr>
                              <td><strong>#{$linha['id']}</strong></td>
                              <td>{$pressao_psi} psi</td>
                              <td>{$temp}°C</td>
                              <td><span class='status {$status}'>{$texto}</span></td>
                              <td>{$hora}</td>
                            </tr>";
                  }
              } else {
                  echo '<tr><td colspan="5" class="empty"><i class="fas fa-inbox"></i><br>Nenhum teste registrado</td></tr>';
              }
              $conn->close();
          }
          ?>
        </table>
      </div>

      <a href="grafico.php" class="btn-grafico">
        <i class="fas fa-chart-line"></i> Ver Gráfico em Tempo Real
      </a>
    </div>
  </div>
</div>

<script>
function updateTime() {
  const now = new Date();
  const time = now.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
  document.getElementById('time').textContent = time;
}
setInterval(updateTime, 1000);
updateTime();
</script>

</body>
</html>
